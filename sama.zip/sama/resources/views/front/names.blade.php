@foreach($names as $item)
{{ $item}}
<br/>
@endforeach