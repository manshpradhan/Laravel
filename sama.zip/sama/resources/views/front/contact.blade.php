@extends('master')

$section('content')

<h1>CONTACT</h1>
@endsection