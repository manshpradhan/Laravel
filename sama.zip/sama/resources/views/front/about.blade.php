@extends('master')

@section('content')
<div class="row">
<div class="col-md-3">
about
</div>

@endsection