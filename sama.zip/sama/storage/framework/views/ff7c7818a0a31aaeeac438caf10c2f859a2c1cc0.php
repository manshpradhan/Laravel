<?php $__env->startSection('content'); ?>
<div class="row">
<div class="col-md-3">
Left Column
</div>
<div class="col-md-7">
Main Content
</div>
<div class="col-md-2">
Advertisement will be here
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>